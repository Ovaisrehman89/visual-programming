LOGIN FOR ADMINISTRATOR
 PRIVILEGE = Administrator
 USERNAME = Admin
 PASSWORD = wiszy

LOGIN FOR NURSE
 PRIVILEGE = Nurse
 USERNAME = vicky
 PASSWORD = 12

NB:
The administrator have full right to access all controls on the form, where as other users will have some controls activated.

Before you can use this app please copy and replace your connection string with the developer's connection string after attaching the database.
the developer connection string is found under the software's code window class clsinsert > dbPath.